let facilities=[], selectedCategory="All";
const searchInput=document.getElementById("searchInput"), facilityList=document.getElementById("facilityList");
const resultCount=document.getElementById("resultCount"), emptyMessage=document.getElementById("emptyMessage"), dialog=document.getElementById("facilityDialog");
const icons={Academic:"▦",Laboratory:"⚗",Facilities:"⌂",Office:"▤"};
async function loadFacilities(){try{const r=await fetch("facilities.json");if(!r.ok)throw Error("Could not load directory");facilities=await r.json();render();}catch(e){facilityList.textContent="Could not load facilities. Please open index.html with Live Server.";console.error(e);}}
function escapeHTML(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function render(){const q=searchInput.value.trim().toLowerCase();const matches=facilities.filter(p=>[p.name,p.category,p.block,p.floor,p.room,p.description].join(" ").toLowerCase().includes(q)&&(selectedCategory==="All"||p.category===selectedCategory));
facilityList.innerHTML=matches.map(p=>{const i=facilities.indexOf(p);return `<article class="card"><div class="card-icon">${icons[p.category]||"⌖"}</div><div class="card-top"><h3>${escapeHTML(p.name)}</h3><span class="pill">${escapeHTML(p.category)}</span></div><p class="loc">${escapeHTML(p.block)} · ${escapeHTML(p.floor)}</p><p>${escapeHTML(p.room)}</p><button class="card-action" data-index="${i}">View details →</button></article>`;}).join("");
resultCount.textContent=matches.length;emptyMessage.classList.toggle("hidden",matches.length!==0);
facilityList.querySelectorAll(".card-action").forEach(b=>b.addEventListener("click",()=>showDetails(facilities[Number(b.dataset.index)])));}
function showDetails(p){document.getElementById("dialogTitle").textContent=p.name;document.getElementById("dialogDescription").textContent=p.description;document.getElementById("dialogBlock").textContent=p.block;document.getElementById("dialogFloor").textContent=p.floor;document.getElementById("dialogRoom").textContent=p.room;dialog.showModal();}
searchInput.addEventListener("input",render);
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");selectedCategory=b.dataset.category;render();}));
document.getElementById("dialogClose").addEventListener("click",()=>dialog.close());
dialog.addEventListener("click",e=>{if(e.target===dialog)dialog.close();});
loadFacilities();

GCEM CAMPUS NAVIGATOR - DESIGN UPDATE

1. Extract this ZIP.
2. In VS Code choose File > Open Folder and select this folder.
3. Open index.html with Live Server.
4. Edit facility records in facilities.json.

FILES:
index.html - page structure
style.css - responsive visual design
script.js - search, category filters and detail pop-up
facilities.json - sample directory data

IMPORTANT: All entries marked Sample and all block/floor/room values are placeholders,
not verified GCEM campus information. Replace them after your campus visit.
The map section is intentionally a placeholder until the real campus layout is surveyed.
